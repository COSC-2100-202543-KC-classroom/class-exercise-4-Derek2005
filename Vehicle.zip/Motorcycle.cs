﻿
// File: Motorcycle.cs
// Project: CarInheritance (Class Exercise 4)
// Author: Uvie Udjo (Student ID: 100879435)
// Date: October 30th, 2025
// Description:
// Motorcycle class inheriting from Vehicle with HasSidecar property.


using System;

namespace CarInheritance
{
    public class Motorcycle : Vehicle
    {
        public bool HasSidecar { get; set; }

        public Motorcycle() : base()
        {
            HasSidecar = false;
        }

        public Motorcycle(string make, string model, int year, decimal price, bool isNew, bool hasSidecar)
            : base()
        {
            Make = make;
            Model = model;
            Year = year;
            Price = price;
            IsNew = isNew;
            HasSidecar = hasSidecar;
        }

        public override string GetInfo()
        {
            return $"{Year} {Make} {Model} ({(IsNew ? "New" : "Used")}) - ${Price:F2}" +
                   (HasSidecar ? " with sidecar." : " without sidecar.");
        }
    }
}

﻿// =============================
// File: MainWindow.xaml.cs
// Project: CarInheritance (Class Exercise 4)
// Author: Uvie Udjo (Student ID: 100879435)
// Date: October 30th, 2025
// Description:
// Handles the logic for the Vehicle Inheritance WPF interface.
// Allows adding Car or Motorcycle objects and displaying them
// inside a ListBox with a running total count.
// =============================

using System;
using System.Collections.Generic;
using System.Runtime.ConstrainedExecution;
using System.Windows;
using System.Windows.Controls;

namespace CarInheritance
{
    public partial class MainWindow : Window
    {
        // Holds all created vehicle objects.
        private readonly List<Vehicle> vehicles = new();

        /// <summary>
        /// Constructor: initializes components and sets up the window.
        /// </summary>
        public MainWindow()
        {
            InitializeComponent();
            UpdateCount();
        }

        /// <summary>
        /// Handles the Add button click — reads form data,
        /// creates either a Car or Motorcycle object,
        /// adds it to the list, and updates the count.
        /// </summary>
        private void btnAdd_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Collect user input from the textboxes
                string make = txtMake.Text.Trim();
                string model = txtModel.Text.Trim();

                // Convert numerical values
                int year = int.Parse(txtYear.Text);
                decimal price = decimal.Parse(txtPrice.Text);

                bool isNew = chkIsNew.IsChecked == true;

                // Determine which type was selected
                string type = ((ComboBoxItem)comboType.SelectedItem).Content.ToString() ?? "Car";

                Vehicle vehicle;

                // Create the correct type of object
                if (type == "Motorcycle")
                    vehicle = new Motorcycle(make, model, year, price, isNew, false);
                else
                    vehicle = new Car(make, model, year, price, isNew, 4);

                // Add to list and display
                vehicles.Add(vehicle);
                listVehicles.Items.Add(vehicle.GetInfo());

                // Clear input boxes for convenience
                txtMake.Clear();
                txtModel.Clear();
                txtYear.Clear();
                txtPrice.Clear();
                chkIsNew.IsChecked = false;
                comboType.SelectedIndex = 0;

                // Update count label
                UpdateCount();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    $"Error: {ex.Message}\n\nPlease make sure Year and Price are valid numbers.",
                    "Invalid Input",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
            }
        }

        /// <summary>
        /// Updates the bottom label to show total vehicles created.
        /// </summary>
        private void UpdateCount()
        {
            lblCount.Text = $"Total Vehicles: {Vehicle.Count}";
        }
    }
}

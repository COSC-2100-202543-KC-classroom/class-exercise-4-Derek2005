﻿
// File: Vehicle.cs
// Project: CarInheritance 
// Author: Uvie Udjo 
// Date: October 30th, 2025
// Description:
// Abstract base class defining shared features for all vehicles.


using System;

namespace CarInheritance
{
    /// <summary>
    /// Abstract class representing a generic vehicle.
    /// </summary>
    public abstract class Vehicle
    {
        private static int count = 0;

        public static int Count => count;

        public int IdentificationNumber { get; private set; }

        public string Make { get; set; } = string.Empty;

        public string Model { get; set; } = string.Empty;

        public int Year { get; set; }

        public decimal Price { get; set; }

        public bool IsNew { get; set; }

        public Vehicle()
        {
            count++;
            IdentificationNumber = count;
        }

        public abstract string GetInfo();
    }
}

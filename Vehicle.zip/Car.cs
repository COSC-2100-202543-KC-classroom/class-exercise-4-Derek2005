﻿
// File: Car.cs
// Project: CarInheritance 
// Author: Uvie Udjo 
// Date: October 30th, 2025
// Description:
// Car class inheriting from Vehicle with extra property Doors.


using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace CarInheritance
{
    public class Car : Vehicle
    {
        public int Doors { get; set; }

        public Car() : base()
        {
            Doors = 4;
        }

        public Car(string make, string model, int year, decimal price, bool isNew, int doors)
            : base()
        {
            Make = make;
            Model = model;
            Year = year;
            Price = price;
            IsNew = isNew;
            Doors = doors;
        }

        public override string GetInfo()
        {
            return $"{Year} {Make} {Model} ({(IsNew ? "New" : "Used")}) - ${Price:F2}, {Doors} doors.";
        }
    }
}
